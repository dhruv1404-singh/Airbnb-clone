const IndexPage = () => {
  return <div>index page</div>;
};
export default IndexPage;
